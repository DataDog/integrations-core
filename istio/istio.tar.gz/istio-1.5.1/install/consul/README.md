# Install Istio with Consul in a simple Docker Compose setup

The install file `istio.yaml` deploys Istio Pilot, Consul, Registrator, and
the Istio API server with etcd as Docker containers.
