# (C) Datadog, Inc. 2013-present
# All rights reserved
# Licensed under Simplified BSD License (see LICENSE)
from datadog_checks.base.checks.win import PDHBaseCheck

DEFAULT_COUNTERS = [
    # counterset, instance of counter, counter name, metric name
    # This set is from the Microsoft recommended counters to monitor active directory:
    # https://technet.microsoft.com/en-us/library/cc961942.aspx
    [
        "NTDS",
        None,
        "DRA Inbound Bytes Compressed (Between Sites, After Compression)/sec",
        "active_directory.dra.inbound.bytes.after_compression",
        "gauge",
    ],
    [
        "NTDS",
        None,
        "DRA Inbound Bytes Compressed (Between Sites, Before Compression)/sec",
        "active_directory.dra.inbound.bytes.before_compression",
        "gauge",
    ],
    [
        "NTDS",
        None,
        "DRA Inbound Bytes Not Compressed (Within Site)/sec",
        "active_directory.dra.inbound.bytes.not_compressed",
        "gauge",
    ],
    ["NTDS", None, "DRA Inbound Bytes Total/sec", "active_directory.dra.inbound.bytes.total", "gauge"],
    [
        "NTDS",
        None,
        "DRA Inbound Full Sync Objects Remaining",
        "active_directory.dra.inbound.objects.remaining",
        "gauge",
    ],
    ["NTDS", None, "DRA Inbound Objects/sec", "active_directory.dra.inbound.objects.persec", "gauge"],
    ["NTDS", None, "DRA Inbound Objects Applied/sec", "active_directory.dra.inbound.objects.applied_persec", "gauge"],
    ["NTDS", None, "DRA Inbound Objects Filtered/sec", "active_directory.dra.inbound.objects.filtered_persec", "gauge"],
    [
        "NTDS",
        None,
        "DRA Inbound Object Updates Remaining in Packet",
        "active_directory.dra.inbound.objects.remaining_in_packet",
        "gauge",
    ],
    [
        "NTDS",
        None,
        "DRA Inbound Properties Applied/sec",
        "active_directory.dra.inbound.properties.applied_persec",
        "gauge",
    ],
    [
        "NTDS",
        None,
        "DRA Inbound Properties Filtered/sec",
        "active_directory.dra.inbound.properties.filtered_persec",
        "gauge",
    ],
    ["NTDS", None, "DRA Inbound Properties Total/sec", "active_directory.dra.inbound.properties.total_persec", "gauge"],
    ["NTDS", None, "DRA Inbound Values (DNs only)/sec", "active_directory.dra.inbound.values.dns_persec", "gauge"],
    ["NTDS", None, "DRA Inbound Values Total/sec", "active_directory.dra.inbound.values.total_persec", "gauge"],
    [
        "NTDS",
        None,
        "DRA Outbound Bytes Compressed (Between Sites, After Compression)/sec",
        "active_directory.dra.outbound.bytes.after_compression",
        "gauge",
    ],
    [
        "NTDS",
        None,
        "DRA Outbound Bytes Compressed (Between Sites, Before Compression)/sec",
        "active_directory.dra.outbound.bytes.before_compression",
        "gauge",
    ],
    [
        "NTDS",
        None,
        "DRA Outbound Bytes Not Compressed (Within Site)/sec",
        "active_directory.dra.outbound.bytes.not_compressed",
        "gauge",
    ],
    ["NTDS", None, "DRA Outbound Bytes Total/sec", "active_directory.dra.outbound.bytes.total", "gauge"],
    [
        "NTDS",
        None,
        "DRA Outbound Objects Filtered/sec",
        "active_directory.dra.outbound.objects.filtered_persec",
        "gauge",
    ],
    ["NTDS", None, "DRA Outbound Objects/sec", "active_directory.dra.outbound.objects.persec", "gauge"],
    ["NTDS", None, "DRA Outbound Properties/sec", "active_directory.dra.outbound.properties.persec", "gauge"],
    ["NTDS", None, "DRA Outbound Values (DNs only)/sec", "active_directory.dra.outbound.values.dns_persec", "gauge"],
    ["NTDS", None, "DRA Outbound Values Total/sec", "active_directory.dra.outbound.values.total_persec", "gauge"],
    # ["NTDS", None, "DRA Remaining Replication Updates", "active_directory.dra.replication.remaining_updates", "gauge"],  # noqa: E501
    [
        "NTDS",
        None,
        "DRA Pending Replication Synchronizations",
        "active_directory.dra.replication.pending_synchronizations",
        "gauge",
    ],
    ["NTDS", None, "DRA Sync Requests Made", "active_directory.dra.sync_requests_made", "gauge"],
    # ["NTDS", None, "DS Security Descriptor Suboperations/sec", "active_directory.ds.security_descriptor.subops_persec", "gauge"],  # noqa: E501
    # ["NTDS", None, "DS Security Descriptor Propagation Events", "active_directory.ds.security_descriptor.propagation_events", "gauge"],  # noqa: E501
    ["NTDS", None, "DS Threads in Use", "active_directory.ds.threads_in_use", "gauge"],
    ["NTDS", None, "LDAP Client Sessions", "active_directory.ldap.client_sessions", "gauge"],
    ["NTDS", None, "LDAP Bind Time", "active_directory.ldap.bind_time", "gauge"],
    ["NTDS", None, "LDAP Successful Binds/sec", "active_directory.ldap.successful_binds_persec", "gauge"],
    ["NTDS", None, "LDAP Searches/sec", "active_directory.ldap.searches_persec", "gauge"],
    # ["NTDS", None, "Kerberos Authentications/sec", "active_directory.kerberos.auths_persec", "gauge"],
    # ["NTDS", None, "NTLM Authentications/sec", "active_directory.ntlm.auths_persec", "gauge"],
]


class ActiveDirectoryCheck(PDHBaseCheck):
    def __init__(self, name, init_config, instances=None):
        super(ActiveDirectoryCheck, self).__init__(
            name, init_config, instances=instances, counter_list=DEFAULT_COUNTERS
        )
